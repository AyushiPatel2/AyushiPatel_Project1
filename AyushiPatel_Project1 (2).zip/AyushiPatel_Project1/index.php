<?php

session_start();
include('db.php');
$status="";
if (isset($_POST['bookid']) && $_POST['bookid']!=""){
$pro = $_POST['pro'];
$result = mysqli_query($con,"SELECT * FROM `bookinventory` WHERE `bookid`='$bookid'");
$row = mysqli_fetch_assoc($result);
$name = $row['name'];
$pro = $row['pro'];
$price = $row['price'];
$version = $row['version'];

    //array for cart
$cartArray = array(
	$pro=>array(
	'name'=>$name,
	'bookid'=>$bookid,
	'price'=>$price,
	'quantity'=>1,
	'version'=>$version)
);

    //shows msg when item is added to cart
if(empty($_SESSION["shopping_cart"])) {
	$_SESSION["shopping_cart"] = $cartArray;
	$status = "<div class='box'>Product is added to your cart!</div>";
}else{
    
    //shows msg if item is already in cart
	$array_keys = array_keys($_SESSION["shopping_cart"]);
	if(in_array($pro,$array_keys)) {
		$status = "<div class='box' style='color:red;'>
		Product is already added to your cart!</div>";	
	} else {
	$_SESSION["shopping_cart"] = array_merge($_SESSION["shopping_cart"],$cartArray);
	$status = "<div class='box'>Product is added to your cart!</div>";
	}

	}
}

?>
<html>
<head>
<title>BookStore</title>
<link rel='stylesheet' href='css/style.css' type='text/css' media='all' />
 <meta name="viewport" content="width=device-width, initial-scale=1">
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <style>
    /* Remove the navbar's default rounded borders and increase the bottom margin */ 
    .navbar {
      margin-bottom: 50px;
      border-radius: 0;
    }
    
  
   
    /* Add a gray background color and some padding to the footer */
    footer {
      background-color: #f2f2f2;
      padding: 25px;
    }

	.navbar {
      margin-bottom: 0;
      border-radius: 0;
    }
    
    /* Add a gray background color and some padding to the footer */
    footer {
      background-color: #f2f2f2;
      padding: 25px;
    }
    
  .carousel-inner img {
      width: 100%; /* Set width to 100% */
      margin: auto;
      min-height:200px;
  }

  /* Hide the carousel text when the screen is less than 600 pixels wide */
  @media (max-width: 600px) {
    .carousel-caption {
      display: none; 
    }
  }
  </style>   
</head> 
<body>


<?php
if (!empty($_SESSION['shopping_cart'])) {
    $cart_count = count(array_keys($_SESSION['shopping_cart']));
}
else{
  $cart_count=null;
}
?>



<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="index.php">BookStore</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active"><a href="index.php">Home</a></li>
        <li><a href="product.php">Products</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
   
        <li><a href="cart.php">cart<span class="glyphicon glyphicon-shopping-cart"></span><?php echo $cart_count; ?></span></a></li>
      </ul>
    </div>
  </div>
</nav>

<div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner" role="listbox">
      <div class="item active">
         <img src="https://www.codewithc.com/wp-content/uploads/2014/12/online-book-store.jpg" alt="Image">
        <div class="carousel-caption">
          <h3>Online Bookstore</h3>
         
        </div>      
      </div>

    
<div class="container text-center">    
  <h3>Newest</h3><br>
  <div class="row">
    <div class="col-sm-4">
      <img src="https://rukminim1.flixcart.com/image/1408/1408/book/6/2/2/php-the-complete-reference-original-imadfzsbhp53rz9e.jpeg?q=90" class="img-responsive" style="width:70%;" alt="Image">
     
    </div>
    <div class="col-sm-4"> 
      <img src="https://it-ebooks.info/images/ebooks/14/beginning_php.jpg" class="img-responsive" style="width:70%" alt="Image">
       
    </div>
    <div class="col-sm-4"> 
      <img src="http://www.it-ebooks.info/images/ebooks/6/beginning_php_and_mysql_e-commerce_2nd_edition.jpg" class="img-responsive" style="width:70%" alt="Image">
      
    </div>
  </div>
</div><br>


<footer class="container-fluid text-center">
  <p>Online BookStore Copyright</p>  
  
</footer>

</body>
</html>