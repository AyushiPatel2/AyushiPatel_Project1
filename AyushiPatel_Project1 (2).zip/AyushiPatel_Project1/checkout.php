<?php 
		
		
        if(!empty($_REQUEST['firstname'])){
            $firstname = $_REQUEST['firstname'];
        }
    else
    {
        $firstname = NULL;
        echo '<p class ="error"> Please enter your first name</p>';
    }
    
     if(!empty($_REQUEST['lastname'])){
            $lastname = $_REQUEST['lastname'];
        }
    else
    {
        $lastname = NULL;
        echo '<p class ="error"> Please enter your last name</p>';
    }
    
     
    
    if(isset($_REQUEST['payment']))
    {
        $payment = $_REQUEST['payment'];
        
        if ($payment == 'debit')
    {
        $message = '<p><strong> Debit</strong></p>';
    } elseif($payment == 'credit')
        {
        $message = '<p><strong> Credit</strong></p>';
    }
    else{
        $payment = NULL;
        echo '<p class = "error">Please Select debit or credit</p>';
    }
    }else 
    {
        $payment = null;
        echo '<p class = "error">Please select payment method</p>';
    }
    
    
    
    if($firstname && $lastname && $payment)
    {
        $servername = "localhost";
$username = "root";
$password = "";
$dbname = "bookstore";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO user (firstname, lastname, payment)
VALUES ('".$_POST["firstname"]."','".$_POST["lastname"]."','".$_POST["payment"]."')";

        //shows alert msg if submits successfully, and redirects to inventory automatically after 3 seconds
if ($conn->query($sql) === TRUE) {
echo "<script type= 'text/javascript'>alert('Thank you for shopping with us...');</script>
";
    echo "<meta http-equiv = 'refresh' content = '3; url =index.php' />";
} else {
echo "<script type= 'text/javascript'>alert('Error: " . $sql . "<br>" . $conn->error."');</script>";
}

$conn->close();
		
		
		
    }else {
		
        echo '<p class = "error"> <strong>Please enter your details.</strong></p>';
    }
    
    

?>


<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Simple HTML Form</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <link href="//maxcdn.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css" rel="stylesheet">
  <style>
    /* Remove the navbar's default rounded borders and increase the bottom margin */ 
    .navbar {
      margin-bottom: 50px;
      border-radius: 0;
    }
    
  
   
    /* Add a gray background color and some padding to the footer */
    footer {
      background-color: #f2f2f2;
      padding: 25px;
    }

	.navbar {
      margin-bottom: 0;
      border-radius: 0;
    }
    .form{
        padding: 50px;
        max-width: 50%;
        margin: auto;
    }

  </style>  
    <style type="text/css">
        label {
            font-weight: bold;
            color: #300ACC;
        }

    </style>

</head>

<body>

<?php
if (!empty($_SESSION['shopping_cart'])) {
    $cart_count = count(array_keys($_SESSION['shopping_cart']));
}
else{
  $cart_count=null;
}
?>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="index.php">Book Store</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active"><a href="index.php">Home</a></li>
        <li><a href="product.php">Products</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
   
        <li><a href="cart.php">cart<span class="glyphicon glyphicon-shopping-cart"></span><?php echo $cart_count; ?></span></a></li>
      </ul>
    </div>
  </div>
</nav>
<h2 class="text-center">Checkout</h2>
<form  method="post" class="form">
  <div class="form-group row">
    <label for="inputfirstname" class="col-sm-2 col-form-label">First Name</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" name="firstname"  placeholder="Enter First Name">
    </div>
  </div>
  <div class="form-group row">
    <label for="inputlastname" class="col-sm-2 col-form-label">Last Name</label>
    <div class="col-sm-10">
      <input type="text" class="form-control"  name="lastname" id="inputlastname" placeholder="Enter Last Name">
    </div>
  </div>
  <fieldset class="form-group">
    <div class="row">
      <label class="col-form-label col-sm-2 pt-0">Payment Type</label>
      <div class="col-sm-10">
        <div class="form-check">
          <input class="form-check-input" type="radio" name="payment" value="debit" >
          <label class="form-check-label" for="gridRadios1">
           Debit
          </label>
        </div>
        <div class="form-check">
          <input class="form-check-input" type="radio"  name="payment" value="credit" >
          <label class="form-check-label" for="gridRadios2">
            Credit
          </label>
        </div>
      </div>
    </div>
  </fieldset>
 
  <div class="form-group row">
    <div class="col-sm-10">
      <button type="submit" name="submit" class="btn btn-primary">Pay Now</button> <a href="product.php" type="submit" class="btn btn-success">Continue Shopping</a>
    </div>
  </div>
</form>

</body>
</html>
